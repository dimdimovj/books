-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2019 at 04:06 PM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booksdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `idbuku` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `idkategori` int(11) DEFAULT NULL,
  `imgfile` varchar(100) DEFAULT NULL,
  `sinopsis` text,
  `thnterbit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`idbuku`, `judul`, `pengarang`, `penerbit`, `idkategori`, `imgfile`, `sinopsis`, `thnterbit`) VALUES
(63, 'Date A Live Vol. 12', 'Kousi Tachibana', 'Fujimi Fantasia Bunko', 6, 'DAL 12.jfif', 'Date A Live, adalah serial light novel Jepang karya Tachibana Koushi, diilustrasikan oleh Tsunako(???), diterbitkan oleh Fujimi Shobo dibawah label Fujimi Fantasia Bunko. Novel ini pertama kali diterbitkan pada Maret 2011. Adaptasi animenya tayang pada April - Juni 2013, menampilkan event-event yang terjadi pada jilid 1-4. Season ke-2 animenya sedang dalam masa produksi.', 2013),
(64, 'Date A Live Vol. 13', 'Kousi Tachibana', 'Fujimi Fantasia Bunko', 6, 'DAL 13.jpg', 'Date A Live, adalah serial light novel Jepang karya Tachibana Koushi, diilustrasikan oleh Tsunako(???), diterbitkan oleh Fujimi Shobo dibawah label Fujimi Fantasia Bunko. Novel ini pertama kali diterbitkan pada Maret 2011. Adaptasi animenya tayang pada April - Juni 2013, menampilkan event-event yang terjadi pada jilid 1-4. Season ke-2 animenya sedang dalam masa produksi.', 2014),
(65, 'Date A Live Vol. 15', 'Kousi Tachibana', 'Fujimi Fantasia Bunko', 6, 'DAL 15.jpg', 'Date A Live, adalah serial light novel Jepang karya Tachibana Koushi, diilustrasikan oleh Tsunako(???), diterbitkan oleh Fujimi Shobo dibawah label Fujimi Fantasia Bunko. Novel ini pertama kali diterbitkan pada Maret 2011. Adaptasi animenya tayang pada April - Juni 2013, menampilkan event-event yang terjadi pada jilid 1-4. Season ke-2 animenya sedang dalam masa produksi.', 2015),
(66, 'Bobo 1', 'Unknown', 'Kelompok Kompas Gramedia', 0, 'Bobo 1.jpg', 'Majalah Bobo adalah bacaan populer anak-anak Indonesia yang terbit sejak 14 April 1973. Majalah ini adalah versi Indonesia dari majalah serupa di Belanda dengan penyesuaian isi. Edisi bahasa Indonesia terbit sekali seminggu, diterbitkan oleh Kelompok Kompas Gramedia. Di Belanda sendiri, majalah Bobo diterbitkan bulanan oleh penerbit Malmberg. ', 2010),
(67, 'Bobo 2', 'Unknown', 'Kelompok Kompas Gramedia', 0, 'Bobo 2.jfif', 'Majalah Bobo adalah bacaan populer anak-anak Indonesia yang terbit sejak 14 April 1973. Majalah ini adalah versi Indonesia dari majalah serupa di Belanda dengan penyesuaian isi. Edisi bahasa Indonesia terbit sekali seminggu, diterbitkan oleh Kelompok Kompas Gramedia. Di Belanda sendiri, majalah Bobo diterbitkan bulanan oleh penerbit Malmberg. ', 2014);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `kategori`) VALUES
(0, 'Majalah'),
(3, 'Skripsi'),
(4, 'Thesis'),
(5, 'Disertasi'),
(6, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `idrole` int(11) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`idrole`, `role`) VALUES
(1, 'admin'),
(2, 'operator');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `idrole` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `fullname`, `idrole`) VALUES
('admin', '123456', 'Administrator', '1'),
('aidimdim', '2908', 'Ai Cherish Yuu', '2'),
('dimdim', '2908', 'Adimas Agustinus', '1'),
('operator', '123456', 'Operator', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`idbuku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`idrole`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `idbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `idrole` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
